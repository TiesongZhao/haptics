//===========================================================================
/*
    This file is part of the CHAI 3D visualization and haptics libraries.
    Copyright (C) 2003-#YEAR# by CHAI 3D. All rights reserved.

    This library is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License("GPL") version 2
    as published by the Free Software Foundation.

    For using the CHAI 3D libraries with software that can not be combined
    with the GNU GPL, and for taking advantage of the additional benefits
    of our support services, please contact CHAI 3D about acquiring a
    Professional Edition License.

    \author:    <http://www.chai3d.org>
    \author:    Federico Barbagli
    \author:    Francois Conti
    \author:    Julius Kammerl
    \version    #CHAI_VERSION#
*/
//===========================================================================

//---------------------------------------------------------------------------
#include "stdafx.h"
#include "assert.h"
#include <conio.h>

#include <process.h>
#include <stdio.h>
#include <windows.h>

//---------------------------------------------------------------------------
#include "hdPhantom.h"
#include <HD/hd.h>
#include <HDU/hduVector.h>
#include <HDU/hduError.h>
//---------------------------------------------------------------------------
#include "chai3d.h"
//---------------------------------------------------------------------------

//=============================================================================
// Global variables
//=============================================================================

// maximum number of Phantom devices
#define PHANTOM_NUM_DEVICES_MAX 2

// stucture used to store data related to each device entity
struct CPhantomDeviceStatus
{
    HHD handle;
    double position[3];
	double linearVelocity[3];
	double rotation[9];
    double force[3];
	double torque[3];
    int    button;
	bool   enabled;
	bool   initialized;
	double workspaceRadius;
	void   (*servoLoopCallback)(int, void*);
	void*  callbackArgument;

};

// has dll been initialed
bool initPhantomDLL = false;

// table containing information for each device.
CPhantomDeviceStatus phantomDevicesContextSchedLoop[PHANTOM_NUM_DEVICES_MAX];

// predefined value that expresses the absence of a Phantom.
int numPhantomDevices = 0;

// has servo controller been started yet
bool servoStarted = false;

// main servo controller callback
HDCallbackCode servoCallbackHandle;
HDCallbackCode HDCALLBACK servoPhantomDevices(void* a_UserData);

// callback for synchronizing device status updates to the haptic servo loop 
HDCallbackCode HDCALLBACK DeviceUpdateContextSyncCallback  (void* a_UserData);
HDCallbackCode HDCALLBACK DeviceUpdateForceSyncCallback    (void *a_UserData);
HDCallbackCode HDCALLBACK DeviceUpdateTorqueSyncCallback   (void *a_UserData);
HDCallbackCode HDCALLBACK DeviceUpdateCallbackSyncCallback (void *a_UserData);

// flag for detecting haptic servo loop activity
bool isHapticLoopSchedulerThreadRunning;

// initialize servo controller
void initServo();

// mutex to manage callbacks
HANDLE mutex;


//=============================================================================
// DLL entry point
// =============================================================================

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
                      )
{

	switch(ul_reason_for_call) {
		case DLL_PROCESS_ATTACH:
			// create windows mutex
			mutex=CreateMutex(NULL, FALSE, NULL);
			break;

		case DLL_PROCESS_DETACH:
			// destroy windows mutex
			CloseHandle(mutex);
			break;
	}

	if (!initPhantomDLL)
	{
		isHapticLoopSchedulerThreadRunning = false;

		initPhantomDLL = true;

		for (int i=0; i<PHANTOM_NUM_DEVICES_MAX; i++)
		{
			// init button data
			phantomDevicesContextSchedLoop[i].button = 0;

			// init position data
			phantomDevicesContextSchedLoop[i].position[0] = 0.0;
			phantomDevicesContextSchedLoop[i].position[1] = 0.0;
			phantomDevicesContextSchedLoop[i].position[2] = 0.0;

			// init rotation data
			phantomDevicesContextSchedLoop[i].rotation[0] = 1.0;
			phantomDevicesContextSchedLoop[i].rotation[1] = 0.0;
			phantomDevicesContextSchedLoop[i].rotation[2] = 0.0;
			phantomDevicesContextSchedLoop[i].rotation[3] = 0.0;
			phantomDevicesContextSchedLoop[i].rotation[4] = 1.0;
			phantomDevicesContextSchedLoop[i].rotation[5] = 0.0;
			phantomDevicesContextSchedLoop[i].rotation[6] = 0.0;
			phantomDevicesContextSchedLoop[i].rotation[7] = 0.0;
			phantomDevicesContextSchedLoop[i].rotation[8] = 1.0;
			
			// init force data
			phantomDevicesContextSchedLoop[i].force[0] = 0.0;
			phantomDevicesContextSchedLoop[i].force[1] = 0.0;
			phantomDevicesContextSchedLoop[i].force[2] = 0.0;
			
			// init torque data
			phantomDevicesContextSchedLoop[i].torque[0] = 0.0;
			phantomDevicesContextSchedLoop[i].torque[1] = 0.0;
			phantomDevicesContextSchedLoop[i].torque[2] = 0.0;

			// init enable/disable data
			phantomDevicesContextSchedLoop[i].enabled = false;

			// init phantom api initialized
			phantomDevicesContextSchedLoop[i].initialized = false;

			// callback pointer
			phantomDevicesContextSchedLoop[i].servoLoopCallback = NULL;
			phantomDevicesContextSchedLoop[i].callbackArgument   = NULL;
		}

		//------------------------------------------------------------------
		// INITIALIZE DEVICES
		//------------------------------------------------------------------	
		HDErrorInfo error;
		numPhantomDevices = 0;

		// search for a first device
		HHD hHD0 = hdInitDevice(HD_DEFAULT_DEVICE);

		// check if device is available
		if (HD_DEVICE_ERROR(error = hdGetError())) 
		{
			return(true);
		}

		// enable forces
		hdMakeCurrentDevice(hHD0);
		hdEnable(HD_FORCE_OUTPUT);

		// add device to list
		phantomDevicesContextSchedLoop[0].handle = hHD0;
		phantomDevicesContextSchedLoop[0].enabled = true;
		numPhantomDevices++;

		// search for a possible second device
		HHD hHD1 = hdInitDevice("Phantom2");

		// check if device is available
		if (HD_DEVICE_ERROR(error = hdGetError())) 
		{
			return(true);
		}

		// enable forces
		hdMakeCurrentDevice(hHD1);
		hdEnable(HD_FORCE_OUTPUT);

		// add device to list
		phantomDevicesContextSchedLoop[1].handle = hHD1;
		phantomDevicesContextSchedLoop[1].enabled = true;
		numPhantomDevices++;
	}

	return (true);
}

//==========================================================================
/*!
    Synchronize to device servo loop and receive the position of the device end-effector.

    \fn       int hdPhantomGetPositionSync(int a_deviceID, 
								            double *a_posX,
								            double *a_posY,
				     			            double *a_posZ)
    \param  a_deviceID device identification number.
    \param  double a_posX Component X of position vector.
    \parma  double a_posY Component Y of position vector.
    \param  double a_posZ Component Z of position vector.
    \return Return 0 if success, otherwise -1.
*/
//==========================================================================
int  hdPhantomGetPositionSync(int a_deviceID, 
							   double *a_posX,
							   double *a_posY,
							   double *a_posZ)
{
	CPhantomDeviceStatus phantomDevicesContext[PHANTOM_NUM_DEVICES_MAX];

	// check id
	if ((a_deviceID < 0) || (a_deviceID >= numPhantomDevices)) { return (-1); }

	// check if servo started
	if (!servoStarted) { hdPhantomStartServo(); }

	// check if enabled
	if (!phantomDevicesContextSchedLoop[a_deviceID].enabled) { return (-1); }

	// schedule to the haptic servo loop and call "DeviceUpdateContextSyncCallback"
	hdScheduleSynchronous(DeviceUpdateContextSyncCallback, &phantomDevicesContext, HD_DEFAULT_SCHEDULER_PRIORITY);

	// get position
	*a_posX = phantomDevicesContext[a_deviceID].position[2];
	*a_posY = phantomDevicesContext[a_deviceID].position[0];
	*a_posZ = phantomDevicesContext[a_deviceID].position[1]; 

	// success
	return (0);
}


//==========================================================================
/*!
    Returns the position of the device end-effector.

    \fn       int hdPhantomGetPositionAsync(int a_deviceID, 
								            double *a_posX,
								            double *a_posY,
				     			            double *a_posZ)
    \param  a_deviceID device identification number.
    \param  double a_posX Component X of position vector.
    \parma  double a_posY Component Y of position vector.
    \param  double a_posZ Component Z of position vector.
    \return Return 0 if success, otherwise -1.
*/
//==========================================================================
int  hdPhantomGetPositionAsync(int a_deviceID, 
 							   double *a_posX,
							   double *a_posY,
							   double *a_posZ)
{
	// check id
	if ((a_deviceID < 0) || (a_deviceID >= numPhantomDevices)) { return (-1); }

	// check if servo started
	if (!servoStarted) { hdPhantomStartServo(); }

	// check if enabled
	if (!phantomDevicesContextSchedLoop[a_deviceID].enabled) { return (-1); }

	// get position
	*a_posX = phantomDevicesContextSchedLoop[a_deviceID].position[2];
	*a_posY = phantomDevicesContextSchedLoop[a_deviceID].position[0];
	*a_posZ = phantomDevicesContextSchedLoop[a_deviceID].position[1]; 

	// success
	return (0);
}


//==========================================================================
/*!
    Synchronize to device servo loop and receive the linear velocity of the device end-effector.

    \fn       int hdPhantomGetLinearVelocitySync(int a_deviceID, 
								                 double *a_posX,
										         double *a_posY,
				     				             double *a_posZ)
    \param  a_deviceID device identification number.
    \param  double a_velX Component X of velocity vector.
    \parma  double a_velY Component Y of velocity vector.
    \param  double a_velZ Component Z of velocity vector.
    \return Return 0 if success, otherwise -1.
*/
//==========================================================================
int hdPhantomGetLinearVelocitySync(int a_deviceID, 
								   double *a_velX,
     	    					   double *a_velY,
								   double *a_velZ)
{
	CPhantomDeviceStatus phantomDevicesContext[PHANTOM_NUM_DEVICES_MAX];

	// check id
	if ((a_deviceID < 0) || (a_deviceID >= numPhantomDevices)) { return (-1); }

	// check if servo started
	if (!servoStarted) { hdPhantomStartServo(); }

	// check if enabled
	if (!phantomDevicesContextSchedLoop[a_deviceID].enabled) { return (-1); }

	// schedule to the haptic servo loop and call "DeviceUpdateContextSyncCallback"
	hdScheduleSynchronous(DeviceUpdateContextSyncCallback, &phantomDevicesContext, HD_DEFAULT_SCHEDULER_PRIORITY);

	// get position
	*a_velX = phantomDevicesContext[a_deviceID].linearVelocity[2];
	*a_velY = phantomDevicesContext[a_deviceID].linearVelocity[0];
	*a_velZ = phantomDevicesContext[a_deviceID].linearVelocity[1];

	// success
	return (0);
}

//==========================================================================
/*!
    Returns the linear velocity of the device end-effector.

    \fn       int hdPhantomGetLinearVelocityAsync(int a_deviceID, 
								                  double *a_posX,
										          double *a_posY,
				     				              double *a_posZ)
    \param  a_deviceID device identification number.
    \param  double a_velX Component X of velocity vector.
    \parma  double a_velY Component Y of velocity vector.
    \param  double a_velZ Component Z of velocity vector.
    \return Return 0 if success, otherwise -1.
*/
//==========================================================================
int hdPhantomGetLinearVelocityAsync(int a_deviceID, 
								    double *a_velX,
		    					    double *a_velY,
								    double *a_velZ)
{
	// check id
	if ((a_deviceID < 0) || (a_deviceID >= numPhantomDevices)) { return (-1); }

	// check if servo started
	if (!servoStarted) { hdPhantomStartServo(); }

	// check if enabled
	if (!phantomDevicesContextSchedLoop[a_deviceID].enabled) { return (-1); }

	// get position
	*a_velX = phantomDevicesContextSchedLoop[a_deviceID].linearVelocity[2];
	*a_velY = phantomDevicesContextSchedLoop[a_deviceID].linearVelocity[0];
	*a_velZ = phantomDevicesContextSchedLoop[a_deviceID].linearVelocity[1];

	// success
	return (0);
}

//==========================================================================
/*!
    Synchronize to device servo loop and receive the orientation matrix (frame) of the device end-effector.

    \fn     int hdPhantomGetRotationSync(int a_deviceID, 
								         double *a_rot00,
								         double *a_rot01,
								         double *a_rot02,
								         double *a_rot10,
								         double *a_rot11,
								         double *a_rot12,
								         double *a_rot20,
								         double *a_rot21,
								         double *a_rot22)
    \param  a_deviceID device identification number.
    \param  double a_rot00 Component [0,0] of rotation matrix.
    \parma  double a_rot01 Component [0,1] of rotation matrix.
    \param  double a_rot02 Component [0,2] of rotation matrix.
    \param  double a_rot10 Component [1,0] of rotation matrix.
    \parma  double a_rot11 Component [1,1] of rotation matrix.
    \param  double a_rot12 Component [1,2] of rotation matrix.
    \param  double a_rot20 Component [2,0] of rotation matrix.
    \parma  double a_rot21 Component [2,1] of rotation matrix.
    \param  double a_rot22 Component [2,2] of rotation matrix.
    \return Return 0 if success, otherwise -1
*/
//==========================================================================
int hdPhantomGetRotationSync(int a_deviceID, 
						     double *a_rot00,
						     double *a_rot01,
						     double *a_rot02,
						     double *a_rot10,
						     double *a_rot11,
						     double *a_rot12,
						     double *a_rot20,
					    	 double *a_rot21,
						     double *a_rot22)
{
	CPhantomDeviceStatus phantomDevicesContext[PHANTOM_NUM_DEVICES_MAX];

	// check id
	if ((a_deviceID < 0) || (a_deviceID >= numPhantomDevices)) { return (-1); }

	// check if servo started
	if (!servoStarted) { hdPhantomStartServo(); }

	// check if enabled
	if (!phantomDevicesContextSchedLoop[a_deviceID].enabled) { return (-1); }

	// schedule to the haptic servo loop and call "DeviceUpdateContextSyncCallback"
	hdScheduleSynchronous(DeviceUpdateContextSyncCallback, &phantomDevicesContext, HD_DEFAULT_SCHEDULER_PRIORITY);

	// return rotation matrix
	/*
	*a_rot00 = phantomDevicesContext[a_deviceID].rotation[8];	
	*a_rot01 = phantomDevicesContext[a_deviceID].rotation[2];	
	*a_rot02 = phantomDevicesContext[a_deviceID].rotation[5];	
	*a_rot10 = phantomDevicesContext[a_deviceID].rotation[6];	
	*a_rot11 = phantomDevicesContext[a_deviceID].rotation[0];	
	*a_rot12 = phantomDevicesContext[a_deviceID].rotation[3];	
	*a_rot20 = phantomDevicesContext[a_deviceID].rotation[7];	
	*a_rot21 = phantomDevicesContext[a_deviceID].rotation[1];	
	*a_rot22 = phantomDevicesContext[a_deviceID].rotation[4];	
	*/

	// read value from matrix and correct matrix to be orthogonal
	// unfortunately there seems be some small errors coming
	// from the OpenHaptics library.
	cVector3d v0, v1, v2;
	v0.set( phantomDevicesContext[a_deviceID].rotation[8],
			phantomDevicesContext[a_deviceID].rotation[6],
			phantomDevicesContext[a_deviceID].rotation[7]);
	v1.set( phantomDevicesContext[a_deviceID].rotation[2],
			phantomDevicesContext[a_deviceID].rotation[0],
			phantomDevicesContext[a_deviceID].rotation[1]);

	v0.normalize();
	v1.normalize();
	v0.crossr(v1, v2);
	v2.crossr(v0, v1);

	*a_rot00 = v0.x;	
	*a_rot01 = v1.x; 
	*a_rot02 = v2.x; 
	*a_rot10 = v0.y; 
	*a_rot11 = v1.y;
	*a_rot12 = v2.y;
	*a_rot20 = v0.z; 
	*a_rot21 = v1.z; 
	*a_rot22 = v2.z;

	// success
	return (0);
}

//==========================================================================
/*!
    Returns the orientation matrix (frame) of the device end-effector.

    \fn     int hdPhantomGetRotationAsync(int a_deviceID, 
								          double *a_rot00,
								          double *a_rot01,
								          double *a_rot02,
								          double *a_rot10,
								          double *a_rot11,
								          double *a_rot12,
								          double *a_rot20,
								          double *a_rot21,
								          double *a_rot22)
    \param  a_deviceID device identification number.
    \param  double a_rot00 Component [0,0] of rotation matrix.
    \parma  double a_rot01 Component [0,1] of rotation matrix.
    \param  double a_rot02 Component [0,2] of rotation matrix.
    \param  double a_rot10 Component [1,0] of rotation matrix.
    \parma  double a_rot11 Component [1,1] of rotation matrix.
    \param  double a_rot12 Component [1,2] of rotation matrix.
    \param  double a_rot20 Component [2,0] of rotation matrix.
    \parma  double a_rot21 Component [2,1] of rotation matrix.
    \param  double a_rot22 Component [2,2] of rotation matrix.
    \return Return 0 if success, otherwise -1
*/
//==========================================================================
int hdPhantomGetRotationAsync(int a_deviceID, 
						      double *a_rot00,
						      double *a_rot01,
						      double *a_rot02,
						      double *a_rot10,
					    	  double *a_rot11,
						      double *a_rot12,
						      double *a_rot20,
						      double *a_rot21,
						      double *a_rot22)
{
	// check id
	if ((a_deviceID < 0) || (a_deviceID >= numPhantomDevices)) { return (-1); }

	// check if servo started
	if (!servoStarted) { hdPhantomStartServo(); }

	// check if enabled
	if (!phantomDevicesContextSchedLoop[a_deviceID].enabled) { return (-1); }

	// return rotation matrix
	/*
	*a_rot00 = phantomDevicesContextSchedLoop[a_deviceID].rotation[8];	
	*a_rot01 = phantomDevicesContextSchedLoop[a_deviceID].rotation[2];	
	*a_rot02 = phantomDevicesContextSchedLoop[a_deviceID].rotation[5];	
	*a_rot10 = phantomDevicesContextSchedLoop[a_deviceID].rotation[6];	
	*a_rot11 = phantomDevicesContextSchedLoop[a_deviceID].rotation[0];	
	*a_rot12 = phantomDevicesContextSchedLoop[a_deviceID].rotation[3];	
	*a_rot20 = phantomDevicesContextSchedLoop[a_deviceID].rotation[7];	
	*a_rot21 = phantomDevicesContextSchedLoop[a_deviceID].rotation[1];	
	*a_rot22 = phantomDevicesContextSchedLoop[a_deviceID].rotation[4];	
	*/

	// read value from matrix and correct matrix to be orthogonal
	// unfortunately there seems be some small errors coming
	// from the OpenHaptics library.
	cVector3d v0, v1, v2;
	v0.set( phantomDevicesContextSchedLoop[a_deviceID].rotation[8],
			phantomDevicesContextSchedLoop[a_deviceID].rotation[6],
			phantomDevicesContextSchedLoop[a_deviceID].rotation[7]);
	v1.set( phantomDevicesContextSchedLoop[a_deviceID].rotation[2],
			phantomDevicesContextSchedLoop[a_deviceID].rotation[0],
			phantomDevicesContextSchedLoop[a_deviceID].rotation[1]);

	v0.normalize();
	v1.normalize();
	v0.crossr(v1, v2);
	v2.crossr(v0, v1);

	*a_rot00 = v0.x;	
	*a_rot01 = v1.x; 
	*a_rot02 = v2.x; 
	*a_rot10 = v0.y; 
	*a_rot11 = v1.y;
	*a_rot12 = v2.y;
	*a_rot20 = v0.z; 
	*a_rot21 = v1.z; 
	*a_rot22 = v2.z;

	// success
	return (0);
}

//==========================================================================
/*!
    Synchronize to device servo loop and receive the values of each end-effector user button.

    \fn     int hdPhantomGetButtonsSync(int a_deviceID)
    \param  a_deviceID device identification number.
    \return Return a integer for which each bit corresponds to a button status.
*/
//==========================================================================
int hdPhantomGetButtonsSync(int a_deviceID)
{
	CPhantomDeviceStatus phantomDevicesContext[PHANTOM_NUM_DEVICES_MAX];

	// check id
	if ((a_deviceID < 0) || (a_deviceID >= numPhantomDevices)) { return (-1); }

	// check if servo started
	if (!servoStarted) { hdPhantomStartServo(); }

	// check if enabled
	if (!phantomDevicesContextSchedLoop[a_deviceID].enabled) { return (-1); }

	// schedule to the haptic servo loop and call "DeviceUpdateContextSyncCallback"
	hdScheduleSynchronous(DeviceUpdateContextSyncCallback, &phantomDevicesContext, HD_DEFAULT_SCHEDULER_PRIORITY);

	// return value
	return (phantomDevicesContext[a_deviceID].button);
}


//==========================================================================
/*!
    Read the values of each end-effector user button.

    \fn     int hdPhantomGetButtonsAsync(int a_deviceID)
    \param  a_deviceID device identification number.
    \return Return a integer for which each bit corresponds to a button status.
*/
//==========================================================================
int hdPhantomGetButtonsAsync(int a_deviceID)
{
	// check id
	if ((a_deviceID < 0) || (a_deviceID >= numPhantomDevices)) { return (-1); }

	// check if servo started
	if (!servoStarted) { hdPhantomStartServo(); }

	// check if enabled
	if (!phantomDevicesContextSchedLoop[a_deviceID].enabled) { return (-1); }

	// return value
	return (phantomDevicesContextSchedLoop[a_deviceID].button);
}



//==========================================================================
/*!
	Synchronize to device servo loop and send a force to the device

    \fn       int hdPhantomSetForceSync(int a_deviceID, 
						                double &a_forceX,
					 		            double &a_forceY,
							            double &a_forceZ)
	\param  a_deviceID device identification number.
	\param  double a_forceX Component X of force vector.
	\parma  double a_forceY Component Y of force vector.
	\param  double a_forceZ Component Z of force vector.
	\return Return 0 if success, otherwise -1
*/
//==========================================================================
int hdPhantomSetForceSync(int a_deviceID, 
					      double *a_forceX,
			              double *a_forceY,
			              double *a_forceZ)
{
	CPhantomDeviceStatus phantomDevicesContext[PHANTOM_NUM_DEVICES_MAX];

	// check id
	if ((a_deviceID < 0) || (a_deviceID >= numPhantomDevices)) { return (-1); }

	// check if servo started
	if (!servoStarted) { hdPhantomStartServo(); }

	// check if enabled
	if (!phantomDevicesContextSchedLoop[a_deviceID].enabled) { return (-1); }

	// schedule to the haptic servo loop and call "DeviceUpdateContextSyncCallback"
	hdScheduleSynchronous(DeviceUpdateContextSyncCallback, &phantomDevicesContext, HD_DEFAULT_SCHEDULER_PRIORITY);

	// set force
	phantomDevicesContext[a_deviceID].force[2] = *a_forceX;
	phantomDevicesContext[a_deviceID].force[0] = *a_forceY;
	phantomDevicesContext[a_deviceID].force[1] = *a_forceZ;

	// schedule to the haptic servo loop and call "DeviceUpdateForceSyncCallback"
	hdScheduleSynchronous(DeviceUpdateForceSyncCallback, &phantomDevicesContext, HD_DEFAULT_SCHEDULER_PRIORITY);

	// success
	return (0);
}


//==========================================================================
/*!
	Send a force to the device

    \fn       int hdPhantomSetForceAsync(int a_deviceID, 
						                 double &a_forceX,
					 		             double &a_forceY,
							             double &a_forceZ)
	\param  a_deviceID device identification number.
	\param  double a_forceX Component X of force vector.
	\parma  double a_forceY Component Y of force vector.
	\param  double a_forceZ Component Z of force vector.
	\return Return 0 if success, otherwise -1
*/
//==========================================================================
int hdPhantomSetForceAsync(int a_deviceID, 
					       double *a_forceX,
			               double *a_forceY,
			               double *a_forceZ)
{

	// check id
	if ((a_deviceID < 0) || (a_deviceID >= numPhantomDevices)) { return (-1); }

	// check if servo started
	if (!servoStarted) { hdPhantomStartServo(); }

	// check if enabled
	if (!phantomDevicesContextSchedLoop[a_deviceID].enabled) { return (-1); }

	// set force
	phantomDevicesContextSchedLoop[a_deviceID].force[2] = *a_forceX;
	phantomDevicesContextSchedLoop[a_deviceID].force[0] = *a_forceY;
	phantomDevicesContextSchedLoop[a_deviceID].force[1] = *a_forceZ;

	// success
	return (0);
}


//==========================================================================
/*!
	Synchronize to device servo loop and send a torque to the device

    \fn       int hdPhantomSetTorqueSync(int a_deviceID, 
						                 double &a_torqueX,
					 		             double &a_torqueY,
							             double &a_torqueZ)
	\param  a_deviceID device identification number.
	\param  double a_torqueX Component X of torque vector.
	\parma  double a_torqueY Component Y of torque vector.
	\param  double a_torqueZ Component Z of torque vector.
	\return Return 0 if success, otherwise -1
*/
//==========================================================================
int hdPhantomSetTorqueSync(int a_deviceID, 
						   double *a_torqueX,
						   double *a_torqueY,
						   double *a_torqueZ)
{
	CPhantomDeviceStatus phantomDevicesContext[PHANTOM_NUM_DEVICES_MAX];

	// check id
	if ((a_deviceID < 0) || (a_deviceID >= numPhantomDevices)) { return (-1); }

	// check if servo started
	if (!servoStarted) { hdPhantomStartServo(); }

	// check if enabled
	if (!phantomDevicesContextSchedLoop[a_deviceID].enabled) { return (-1); }

	// schedule to the haptic servo loop and call "DeviceUpdateContextSyncCallback"
	hdScheduleSynchronous(DeviceUpdateContextSyncCallback, &phantomDevicesContext, HD_DEFAULT_SCHEDULER_PRIORITY);

	// set force
	phantomDevicesContext[a_deviceID].torque[2] = *a_torqueX;
	phantomDevicesContext[a_deviceID].torque[0] = *a_torqueY;
	phantomDevicesContext[a_deviceID].torque[1] = *a_torqueZ;

	// schedule to the haptic servo loop and call "DeviceUpdateTorqueSyncCallback"
	hdScheduleSynchronous(DeviceUpdateTorqueSyncCallback, &phantomDevicesContext, HD_DEFAULT_SCHEDULER_PRIORITY);

	// success
	return (0);
}



//==========================================================================
/*
        Set scheduler loop callback function 

        \fn     void  hdPhantomSetServoCallbackAsync(void(* a_callback)(int), int a_deviceID, void* a_arg)
	    \param  void(* a_callback)(int) pointer to callback function 
		\param  a_deviceID device ID
		\param  a_arg argument passed to callback function
*/
//==========================================================================
void  hdPhantomSetServoCallbackAsync(void(* a_callback)(int, void*), int a_deviceID, void* a_arg) {

	phantomDevicesContextSchedLoop[a_deviceID].servoLoopCallback = a_callback;
	phantomDevicesContextSchedLoop[a_deviceID].callbackArgument = a_arg;

}

//==========================================================================
/*
        Synchronize to device servo loop and set scheduler loop callback function  

        \fn     void  hdPhantomSetServoCallbackSync(void(* a_callback)(int, void*), int a_deviceID, void* a_arg)
	    \param  void(* a_callback)(int) pointer to callback function 
		\param  a_deviceID device ID
		\param  a_arg argument passed to callback function
*/
//==========================================================================
void  hdPhantomSetServoCallbackSync(void(* a_callback)(int, void*), int a_deviceID, void* a_arg) {
	CPhantomDeviceStatus phantomDevicesContext[PHANTOM_NUM_DEVICES_MAX];

	// schedule to the haptic servo loop and call "DeviceUpdateContextSyncCallback"
	hdScheduleSynchronous(DeviceUpdateContextSyncCallback, &phantomDevicesContext, HD_DEFAULT_SCHEDULER_PRIORITY);

	phantomDevicesContext[a_deviceID].servoLoopCallback = a_callback;
	phantomDevicesContext[a_deviceID].callbackArgument   = a_arg;

	// schedule to the haptic servo loop and call "DeviceUpdateCallbackSyncCallback"
	hdScheduleSynchronous(DeviceUpdateCallbackSyncCallback, &phantomDevicesContext, HD_DEFAULT_SCHEDULER_PRIORITY);
}


//==========================================================================
/*!
	Send a torque to the device

    \fn       int hdPhantomSetTorqueAsync(int a_deviceID, 
						                  double &a_torqueX,
					 		              double &a_torqueY,
							              double &a_torqueZ)
	\param  a_deviceID device identification number.
	\param  double a_torqueX Component X of torque vector.
	\parma  double a_torqueY Component Y of torque vector.
	\param  double a_torqueZ Component Z of torque vector.
	\return Return 0 if success, otherwise -1
*/
//==========================================================================
int hdPhantomSetTorqueAsync(int a_deviceID, 
						    double *a_torqueX,
							double *a_torqueY,
							double *a_torqueZ)
{
	// check id
	if ((a_deviceID < 0) || (a_deviceID >= numPhantomDevices)) { return (-1); }

	// check if servo started
	if (!servoStarted) { hdPhantomStartServo(); }

	// check if enabled
	if (!phantomDevicesContextSchedLoop[a_deviceID].enabled) { return (-1); }

	// set force
	phantomDevicesContextSchedLoop[a_deviceID].torque[2] = *a_torqueX;
	phantomDevicesContextSchedLoop[a_deviceID].torque[0] = *a_torqueY;
	phantomDevicesContextSchedLoop[a_deviceID].torque[1] = *a_torqueZ;

	// success
	return (0);
}


//==========================================================================
// FUNCTIONS ACCESSIBLE FROM OUTSIDE
//==========================================================================

//==========================================================================
/*!
    Retrieves the number of devices of type phantom.

    \fn     int hdPhantomGetNumDevices()
    \return returns the number of devices found      
*/
//==========================================================================
__declspec(dllexport) int __stdcall hdPhantomGetNumDevices() 
{
	return (numPhantomDevices);
}


//==========================================================================
/*!
    Open a connexion to the device selected by a_deviceID.

    \fn     int hdPhantomOpen(int a_deviceID)
    \param  a_deviceID device identification number. 
    \return Return 0 if success, otherwise -1.
*/
//==========================================================================
__declspec(dllexport) int __stdcall hdPhantomOpen(int a_deviceID)
{
	// check id
	if ((a_deviceID < 0) || (a_deviceID >= numPhantomDevices)) { return (-1); }

	// init device
	if (!phantomDevicesContextSchedLoop[a_deviceID].initialized)
	{
		phantomDevicesContextSchedLoop[a_deviceID].initialized = true;
	}

	// enable device
	phantomDevicesContextSchedLoop[a_deviceID].enabled = true;

	// return result
	return (phantomDevicesContextSchedLoop[a_deviceID].handle);
}


//==========================================================================
/*!
    Closes a connexion to the device selected by a_deviceID.

    \fn     int hdPhantomClose(int a_deviceID)
    \param  a_deviceID device identification number. 
    \return Return 0 if success, otherwise -1.
*/
//==========================================================================
__declspec(dllexport) int __stdcall hdPhantomClose(int a_deviceID)
{
	// check id
	if ((a_deviceID < 0) || (a_deviceID >= numPhantomDevices)) { return (-1); }

	// disable device
	phantomDevicesContextSchedLoop[a_deviceID].enabled = false;

    // exit
    return (0);
}


//==========================================================================
/*!
    Returns the position of the device end-effector.

    \fn       int hdPhantomGetPosition(int a_deviceID, 
								    double *a_posX,
								    double *a_posY,
				     			    double *a_posZ)
    \param  a_deviceID device identification number.
    \param  double a_posX Component X of position vector.
    \parma  double a_posY Component Y of position vector.
    \param  double a_posZ Component Z of position vector.
    \return Return 0 if success, otherwise -1.
*/
//==========================================================================
__declspec(dllexport) int __stdcall hdPhantomGetPosition(int a_deviceID, 
														double *a_posX,
														double *a_posY,
														double *a_posZ)
{

	if (isHapticLoopSchedulerThreadRunning) {
		hdPhantomGetPositionAsync(a_deviceID, a_posX,a_posY,a_posZ);
	} else {
		hdPhantomGetPositionSync(a_deviceID, a_posX,a_posY,a_posZ);
	}

	// success
	return (0);
}


//==========================================================================
/*!
    Returns the linear velocity of the device end-effector.

    \fn       int hdPhantomGetLinearVelocity(int a_deviceID, 
								            double *a_posX,
										    double *a_posY,
				     				        double *a_posZ)
    \param  a_deviceID device identification number.
    \param  double a_velX Component X of velocity vector.
    \parma  double a_velY Component Y of velocity vector.
    \param  double a_velZ Component Z of velocity vector.
    \return Return 0 if success, otherwise -1.
*/
//==========================================================================
__declspec(dllexport) int __stdcall hdPhantomGetLinearVelocity(int a_deviceID, 
								                               double *a_velX,
		    					                               double *a_velY,
								                               double *a_velZ) 
{
	if (isHapticLoopSchedulerThreadRunning) {
		hdPhantomGetLinearVelocityAsync(a_deviceID, a_velX,a_velY,a_velZ);
	} else {
		hdPhantomGetLinearVelocitySync(a_deviceID, a_velX,a_velY,a_velZ);
	}

	// success
	return (0);
}




//==========================================================================
/*!
    Returns the orientation matrix (frame) of the device end-effector.

    \fn     int hdPhantomGetRotation(int a_deviceID, 
								    double *a_rot00,
								    double *a_rot01,
								    double *a_rot02,
								    double *a_rot10,
								    double *a_rot11,
								    double *a_rot12,
								    double *a_rot20,
								    double *a_rot21,
								    double *a_rot22)
    \param  a_deviceID device identification number.
    \param  double a_rot00 Component [0,0] of rotation matrix.
    \parma  double a_rot01 Component [0,1] of rotation matrix.
    \param  double a_rot02 Component [0,2] of rotation matrix.
    \param  double a_rot10 Component [1,0] of rotation matrix.
    \parma  double a_rot11 Component [1,1] of rotation matrix.
    \param  double a_rot12 Component [1,2] of rotation matrix.
    \param  double a_rot20 Component [2,0] of rotation matrix.
    \parma  double a_rot21 Component [2,1] of rotation matrix.
    \param  double a_rot22 Component [2,2] of rotation matrix.
    \return Return 0 if success, otherwise -1
*/
//==========================================================================
__declspec(dllexport) int __stdcall hdPhantomGetRotation(int a_deviceID, 
						double *a_rot00,
						double *a_rot01,
						double *a_rot02,
						double *a_rot10,
						double *a_rot11,
						double *a_rot12,
						double *a_rot20,
						double *a_rot21,
						double *a_rot22)
{
	if (isHapticLoopSchedulerThreadRunning) {
		hdPhantomGetRotationAsync(a_deviceID, a_rot00,a_rot01,a_rot02,a_rot10,a_rot11,a_rot12,a_rot20,a_rot21,a_rot22);
	} else {
		hdPhantomGetRotationSync (a_deviceID, a_rot00,a_rot01,a_rot02,a_rot10,a_rot11,a_rot12,a_rot20,a_rot21,a_rot22);
	}

	// success
	return (0);
}




//==========================================================================
/*!
    Read the values of each end-effector user button.

    \fn     int hdPhantomGetButtons(int a_deviceID)
    \param  a_deviceID device identification number.
    \return Return a integer for which each bit corresponds to a button status.
*/
//==========================================================================
__declspec(dllexport) int __stdcall hdPhantomGetButtons(int a_deviceID)
{
	int retVal;

	if (isHapticLoopSchedulerThreadRunning) {
		retVal = hdPhantomGetButtonsAsync(a_deviceID);
	} else {
		retVal = hdPhantomGetButtonsSync(a_deviceID);
	}

	// return value
	return retVal;
}

//==========================================================================
/*!
	Send a force to the device

    \fn       int hdSetForce(int a_deviceID, 
						     double &a_forceX,
					 		 double &a_forceY,
							 double &a_forceZ)
	\param  a_deviceID device identification number.
	\param  double a_forceX Component X of force vector.
	\parma  double a_forceY Component Y of force vector.
	\param  double a_forceZ Component Z of force vector.
	\return Return 0 if success, otherwise -1
*/
//==========================================================================
__declspec(dllexport) int __stdcall hdPhantomSetForce(int a_deviceID, 
					 double *a_forceX,
			         double *a_forceY,
			         double *a_forceZ)
{

	if (isHapticLoopSchedulerThreadRunning) {
		hdPhantomSetForceAsync(a_deviceID,a_forceX,a_forceY,a_forceZ);
	} else {
		hdPhantomSetForceSync(a_deviceID,a_forceX,a_forceY,a_forceZ);
	}

	// success
	return (0);
}



//==========================================================================
/*!
	Send a torque to the device

    \fn       int hdSetForce(int a_deviceID, 
						     double &a_torqueX,
					 		 double &a_torqueY,
							 double &a_torqueZ)
	\param  a_deviceID device identification number.
	\param  double a_torqueX Component X of torque vector.
	\parma  double a_torqueY Component Y of torque vector.
	\param  double a_torqueZ Component Z of torque vector.
	\return Return 0 if success, otherwise -1
*/
//==========================================================================
__declspec(dllexport) int __stdcall hdPhantomSetTorque(int a_deviceID, 
							  double *a_torqueX,
							  double *a_torqueY,
							  double *a_torqueZ)
{
	if (isHapticLoopSchedulerThreadRunning) {
		hdPhantomSetTorqueAsync(a_deviceID,a_torqueX,a_torqueY,a_torqueZ);
	} else {
		hdPhantomSetTorqueSync(a_deviceID,a_torqueX,a_torqueY,a_torqueZ);
	}

	// success
	return (0);
}

//==========================================================================
/*!
	Get Workspace Radius

    \fn     int hdPhantomGetWorkspaceRadius(int a_deviceID, double *a_workspaceRadius)
	\param  a_deviceID device identification number.
	\param  a_workspaceRadius  Radius of the workspace
	\return Return 0 if success, otherwise -1
*/
//==========================================================================
__declspec(dllexport) int __stdcall hdPhantomGetWorkspaceRadius(int a_deviceID, double *a_workspaceRadius)
{
	// check id
	if ((a_deviceID < 0) || (a_deviceID >= numPhantomDevices)) { return (-1); }

	// check if servo started
	if (!servoStarted) { hdPhantomStartServo(); }

	// check if enabled
	if (!phantomDevicesContextSchedLoop[a_deviceID].enabled) { return (-1); }

	// retrieve handle
	HHD hHD = phantomDevicesContextSchedLoop[a_deviceID].handle;

	// activate ith device
	hdMakeCurrentDevice(hHD);

	// read workspace of device
	double size[6];
	hdGetDoublev(HD_USABLE_WORKSPACE_DIMENSIONS, size);
	double sizeX = size[3] - size[0];
	double sizeY = size[4] - size[1];
	double sizeZ = size[5] - size[2];
	double radius = 0.5 * sqrt(sizeX * sizeX +
				     		   sizeY * sizeY +
					           sizeZ * sizeZ);

	// convert value to [m]
	phantomDevicesContextSchedLoop[a_deviceID].workspaceRadius = 0.001 * radius;

	// return estimated workspace radius
	*a_workspaceRadius = phantomDevicesContextSchedLoop[a_deviceID].workspaceRadius;

	// success
	return (0);
}


//==========================================================================
/*!
	Read the name type of the device

    \fn     __declspec(dllexport) int __stdcall hdPhantomGetType(int a_deviceID, 
													 const char* a_typeName)
	\param  a_deviceID device identification number.
	\param  a_typeName  String containing the the device type
	\return Return 0 if success, otherwise -1
*/
//==========================================================================
__declspec(dllexport) int __stdcall hdPhantomGetType(int a_deviceID, 
													 char* a_typeName)
{
	// check id
	if ((a_deviceID < 0) || (a_deviceID >= numPhantomDevices)) { return (-1); }

	// check if servo started
	if (!servoStarted) { hdPhantomStartServo(); }

	// check if enabled
	if (!phantomDevicesContextSchedLoop[a_deviceID].enabled) { return (-1); }

	// retrieve handle
	HHD hHD = phantomDevicesContextSchedLoop[a_deviceID].handle;

	// activate ith device
	hdMakeCurrentDevice(hHD);

	// read device model
	const char* typeName = hdGetString(HD_DEVICE_MODEL_TYPE);
	strcpy(a_typeName, typeName);

    // exit
    return (0);
}


//==========================================================================
/*
        start servo controller

        \fn     __declspec(dllexport) void __stdcall hdPhantomStartServo(void)
*/
//==========================================================================
__declspec(dllexport) void __stdcall hdPhantomStartServo(void)
{
	if (!servoStarted)
	{
		// servo controller has been started
		servoStarted = true;

		// create callback
		HDCallbackCode servoCallbackHandle = hdScheduleAsynchronous(
		servoPhantomDevices, NULL, HD_DEFAULT_SCHEDULER_PRIORITY);

		// start scheduler
		hdStartScheduler();
	}
}


//==========================================================================
/*
        stop  servo controller

        \fn     __declspec(dllexport) void __stdcall hdPhantomStopServo(void)
*/
//==========================================================================
__declspec(dllexport) void __stdcall hdPhantomStopServo(void)
{
	if (servoStarted)
	{
		// check if any device is enabled
		bool deviceEnabled = false;
		for (int i=0; i<PHANTOM_NUM_DEVICES_MAX; i++)
		{
		   deviceEnabled = deviceEnabled || phantomDevicesContextSchedLoop[i].enabled;
		}

		// if a device is still enabled, do not stop servo loop
		if (deviceEnabled) { return; };

		// stop servo controller
		servoStarted = false;
		hdStopScheduler();
	}
}



//==========================================================================
/*
        set scheduler loop callback function pointer with argument

        \fn     __declspec(dllexport) void __stdcall hdPhantomSetSchedLooa_callback(void(* a_callback)(int), int a_deviceID)
	    \param  void(* a_callback)(int) pointer to callback function 
		\param  a_deviceID device ID
		\param  a_arg argument passed to callback function
*/
//==========================================================================
__declspec(dllexport) void __stdcall hdPhantomSetServoCallback(void(* a_callback)(int, void*), int a_deviceID, void* a_arg) {

	if (isHapticLoopSchedulerThreadRunning) { // check for servo controller thread activity
		hdPhantomSetServoCallbackAsync(a_callback, a_deviceID, a_arg); // update the callback function pointer
	} else {
		hdPhantomSetServoCallbackSync(a_callback, a_deviceID, a_arg); // synchronize to the servo loop and update the callback function pointer
	}
}




//==========================================================================
// FUNCTIONS INTERNAL TO THE DLL
//==========================================================================


//==========================================================================
/*
	servo controller callback

	\fn     HDLServoOpExitCode servoPhantomDevices(void* a_UserData)
	\param  a_UserData pointer to user data information (not used here)
*/
//==========================================================================
HDCallbackCode HDCALLBACK servoPhantomDevices(void* a_UserData)
{

	DWORD dwWaitResult;
	dwWaitResult = WaitForSingleObject(mutex, 0);

	// check mutex if the haptic thread is busy
	if (dwWaitResult==WAIT_OBJECT_0) {

		HHD hHD[PHANTOM_NUM_DEVICES_MAX];

		for (int i=0; i<PHANTOM_NUM_DEVICES_MAX; i++)
		{
			// for each activated phantom device
			if (phantomDevicesContextSchedLoop[i].enabled)
			{
				// retrieve handle
				hHD[i] = phantomDevicesContextSchedLoop[i].handle;

				// activate ith device
				hdMakeCurrentDevice(hHD[i]);
				
				// retrieve the position and orientation of the end-effector.
				double frame[16];
				hdGetDoublev(HD_CURRENT_TRANSFORM, frame);

				// convert position from [mm] to [m] 
				frame[12] = frame[12] * 0.001;
				frame[13] = frame[13] * 0.001;
				frame[14] = frame[14] * 0.001;

				phantomDevicesContextSchedLoop[i].position[0] = frame[12];
				phantomDevicesContextSchedLoop[i].position[1] = frame[13];
				phantomDevicesContextSchedLoop[i].position[2] = frame[14];

				phantomDevicesContextSchedLoop[i].rotation[0] = frame[0];
				phantomDevicesContextSchedLoop[i].rotation[1] = frame[1];
				phantomDevicesContextSchedLoop[i].rotation[2] = frame[2];
				phantomDevicesContextSchedLoop[i].rotation[3] = frame[4];
				phantomDevicesContextSchedLoop[i].rotation[4] = frame[5];
				phantomDevicesContextSchedLoop[i].rotation[5] = frame[6];
				phantomDevicesContextSchedLoop[i].rotation[6] = frame[8];
				phantomDevicesContextSchedLoop[i].rotation[7] = frame[9];
				phantomDevicesContextSchedLoop[i].rotation[8] = frame[10];

				// read linear velocity
				double vel[3];
				hdGetDoublev(HD_CURRENT_VELOCITY, vel);

				// convert position from [mm] to [m] 
				vel[0] = vel[0] * 0.001;
				vel[1] = vel[1] * 0.001;
				vel[2] = vel[2] * 0.001;
				
				phantomDevicesContextSchedLoop[i].linearVelocity[0] = vel[0];
				phantomDevicesContextSchedLoop[i].linearVelocity[1] = vel[1];
				phantomDevicesContextSchedLoop[i].linearVelocity[2] = vel[2];

				// read user buttons
				int buttons;
				hdGetIntegerv(HD_CURRENT_BUTTONS, &buttons);
				phantomDevicesContextSchedLoop[i].button = buttons;

			}
		}

		// setting server loop activity flag - device context/status can be directely changed
		isHapticLoopSchedulerThreadRunning = true;  

		for (int i=0; i<PHANTOM_NUM_DEVICES_MAX; i++) {
			// excecute callback function
			if (phantomDevicesContextSchedLoop[i].servoLoopCallback)
				phantomDevicesContextSchedLoop[i].servoLoopCallback(i, phantomDevicesContextSchedLoop[i].callbackArgument);
		}

		// removing server loop activity flag - device context/status updates should be synchronized to the servo loop thread
		isHapticLoopSchedulerThreadRunning = false;  
		
		for (int i=0; i<PHANTOM_NUM_DEVICES_MAX; i++)
		{
			// for each activated phantom device
			if (phantomDevicesContextSchedLoop[i].enabled)
			{			
				// activate ith device
				hdMakeCurrentDevice(hHD[i]);

				// start sending commands
				hdBeginFrame(hHD[i]);

				// send force to end-effector
				double force[3];
				force[0] = phantomDevicesContextSchedLoop[i].force[0];
				force[1] = phantomDevicesContextSchedLoop[i].force[1];
				force[2] = phantomDevicesContextSchedLoop[i].force[2];
				hdSetDoublev(HD_CURRENT_FORCE, force);

				// send torque to end-effector
				double torque[3];
				torque[0] = phantomDevicesContextSchedLoop[i].torque[0];
				torque[1] = phantomDevicesContextSchedLoop[i].torque[1];
				torque[2] = phantomDevicesContextSchedLoop[i].torque[2];
				hdSetDoublev(HD_CURRENT_GIMBAL_TORQUE, torque);

				// flush commands
				hdEndFrame(hHD[i]);
			}
		}
		// release mutex
		ReleaseMutex(mutex);
	}

	return (HD_CALLBACK_CONTINUE);
}

//==========================================================================
/*!
    servo controller callback that copies the device context

	\fn     HDCallbackCode DeviceUpdateContextSyncCallback(void* a_UserData)
	\param  a_UserData pointer to device context information 

    \return HD_CALLBACK_DONE.
*/
//==========================================================================

HDCallbackCode HDCALLBACK DeviceUpdateContextSyncCallback(void *a_UserData) {

	// copy the device status/context
	memcpy(a_UserData, phantomDevicesContextSchedLoop, sizeof(phantomDevicesContextSchedLoop));

	return HD_CALLBACK_DONE;
}

//==========================================================================
/*!
    servo controller callback for safely updating the force feedback of the device end-effector.

	\fn     HDLServoOpExitCode DeviceUpdateForceSyncCallback(void* a_UserData)
	\param  a_UserData pointer to device context information 

    \return HD_CALLBACK_DONE.
*/
//==========================================================================

HDCallbackCode HDCALLBACK DeviceUpdateForceSyncCallback(void *a_UserData) {
	int i;
	CPhantomDeviceStatus* phantomDevicesContext = (CPhantomDeviceStatus*) a_UserData; 

	for (i=0; i<numPhantomDevices; i++) {
		memcpy(phantomDevicesContextSchedLoop[i].force, phantomDevicesContext[i].force, sizeof(phantomDevicesContextSchedLoop[i].force));
	}

	return HD_CALLBACK_DONE;
}

//==========================================================================
/*!
   servo controller callback for safely updating the torque feedback of the device end-effector.

	\fn     HDLServoOpExitCode DeviceUpdateTorqueSyncCallback(void* a_UserData)
	\param  a_UserData pointer to device context information 

    \return HD_CALLBACK_DONE.
*/
//==========================================================================

HDCallbackCode HDCALLBACK DeviceUpdateTorqueSyncCallback(void *a_UserData) {
	int i;
	CPhantomDeviceStatus* phantomDevicesContext = (CPhantomDeviceStatus*) a_UserData; 

	for (i=0; i<numPhantomDevices; i++) {
		memcpy(phantomDevicesContextSchedLoop[i].torque, phantomDevicesContext[i].torque, sizeof(phantomDevicesContextSchedLoop[i].torque));
	}

	return HD_CALLBACK_DONE;

}

//==========================================================================
/*!
   servo controller callback for safely updating the callback function pointer.

	\fn     HDLServoOpExitCode DeviceUpdateCallbackSyncCallback(void* a_UserData)
	\param  a_UserData pointer to device context information 

    \return HD_CALLBACK_DONE.
*/
//==========================================================================

HDCallbackCode HDCALLBACK DeviceUpdateCallbackSyncCallback(void *a_UserData) {
	int i;
	CPhantomDeviceStatus* phantomDevicesContext = (CPhantomDeviceStatus*) a_UserData; 

	for (i=0; i<numPhantomDevices; i++) {
		phantomDevicesContextSchedLoop[i].servoLoopCallback = phantomDevicesContext[i].servoLoopCallback;
		phantomDevicesContextSchedLoop[i].callbackArgument   = phantomDevicesContext[i].callbackArgument;
	}

	return HD_CALLBACK_DONE;
}