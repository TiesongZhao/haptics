Installation instructions:

Windows: 
1-Installation of Haptic Device:

- Falcon haptic device: Run setup.Falcon.v4.0.28.0_100707.exe and follow the installation instructions of the haptic device

2-Installation and compilation of Chai3d: The project document is under the following path

				/examples/msvc9/CHAI3D.sln

- Click on the solution to open it with MS Visual Studio (����ʹ��Visual Studio 2013�汾)

- There are two projects: CHAI3D and HapticCommunicationDemo

- Build the solution (if CHAI3D is compiled for the first time, it may take some time)

- Set the HapticCommunicationDemo project as "StartUp Project" by right clicking on the project

3- Running demo application to test Haptic Communication library  

IMPORTANT NOTE: When you first run the falcon device, it needs calibration to display the force feedback. Otherwise, you don't feel any force feedback. 
		If the device is not calibrated, you see a red color on the front led. To calibrate, move all joints to their limits. When the led turns blue, 
		the device is successfully calibrated.

- The path of the haptic communication library is as follows:

				/examples/msvc9/HapticCommunicationDemo

- All necessary source files are located under "/src" folder
- The configuration file "config.cfg" is located under "/cfg" folder

- Before running the application, adjust your desired deadband parameters, delay condition, select control mode (position or velocity) in "config.cfg"
- In "config.cgf", there exists a flag called "RecordSignals" to save the signals of the teleoperation session into text files for further analysis. (please see item 3)

RecordSignals = 1;   // 0: Turn off recording, 1: Turn on recording

ForceDeadbandParameter     = 0.1; // deadband parameter for force data reduction
VelocityDeadbandParameter  = 0.1; // deadband parameter for velocity data reduction 
PositionDeadbandParameter  = 0.01;// deadband parameter for position data reduction
ForceDelay		   = 1;   // ms: constant network delay on Force feedback
CommandDelay               = 1;   // ms: constant network delay on Commanding channel  
ControlMode                = 0;   // 0: position control, 1:velocity control
FlagVelocityKalmanFilter   = 0;   // 0: Kalman filter disabled 1: Kalman filter enabled on velocity signal

###############################################################################
��������

HapticCommLib.h�ļ�
#define M 300 	//����MΪ,����ApplyJPEG����֮ǰ,����������Ҫ�Ŵ�ı�������Mp/f

HapticCommunicationDemo.cpp�ļ�
ifstream fin("Data traces//Static_interaction_dragging_surface_25s_RecordedTOPSession_DB.txt", ios::in);  //ѡ��ʹ�õı�׼���ݼ�
###############################################################################

Running the codec in Debug mode:
- Run the application using the play button in Visual studio
 
- In real-time you can increase or decrease the deadband parameter for position, velocity and force signals. 
Please follow the instruction screen of the application for the relevant keys as shown below:

******* Control mode keys *********************************
[p] - switch to position control : switches to position commanding mode
[v] - switch to velocity control : switches to velocity commanding mode
[k] - enable/disable Kalman filter on velocity: performs kalman filtering to reduce the noise on velocity
***********************************************************

******* Deadband increase/decrease keys *******************
[q] - increase force deadband (+0.01)
[a] - decrease force deadband (-0.01)
[w] - increase velocity/position deadband (+0.01) : increases the deadband for corresponding control mode
[s] - decrease velocity/position deadband (-0.01) : decreases the deadband for corresponding control mode
***********************************************************

******* Virtual Environment Control keys ******************
[r] - move the cube to its initial position (reset button)
[x] - Exit application


- Workspace adjustment : If you reach the limit of the physical workspace of the device, you press the middle botton ("id=1") of the Falcon device and stop the movement of the virtual
tool. Then, you can readjust your device handle and press the button again to restart controlling the virtual tool. With this you can reach all regions of the virtual workspace.
It is important to note that the position drift occurs only in velocity commanding mode, therefore this button is active only for velocity commanding mode.

Running the codec without Visual Studio using the precompiled executable:
- You can copy the "/bin" folder to another location to test the application. 
- You can directly run the exexutable "HapticCommunicationDemo.exe" under "/bin" folder.
- In this case the configuration file under "/bin/cfg/config.cfg" is in use by the codec. 

3- Analyzing the results:

- Deadband mode: If "RecordSignals" flag is enabled in "config.cfg", the force feedback and velocity signals 
before and after deadband data reduction are recorded into "RecordedTOPSession_DB.txt". Under the project path, there exists a matlab script to plot the signals using MATLAB:
"/HapticCommunicationDemo
/AnalyzeResultsDB.m"


